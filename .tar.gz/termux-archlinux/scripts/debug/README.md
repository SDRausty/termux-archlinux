These debugging scripts are a pleasure to use: 

1) `sraf.sh` has a very simple function. It is to remove `$HOME/arch` completely.  Please use `sraf.sh` with caution, ideally on a device dedicated to debugging.  
