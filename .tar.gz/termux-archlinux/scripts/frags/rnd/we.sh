#!/bin/bash
watch cat /proc/sys/kernel/random/entropy_avail
