Various script fragments. 
