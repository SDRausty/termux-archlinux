#!/bin/sh -e 
# Copyright 2017 (c) all rights reserved 
# by S D Rausty https://sdrausty.github.io
# Update submodules to latest version. 
#####################################################################
git submodule add https://github.com/sdrausty/dfa scripts/frags/dfa
