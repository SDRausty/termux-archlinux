#!/bin/sh -e 
# Copyright 2018 (c) all rights reserved 
# by S D Rausty https://sdrausty.github.io
# Update submodules to latest version. 
#####################################################################
git submodule add https://github.com/sdrausty/imgsTermuxArch imgs
